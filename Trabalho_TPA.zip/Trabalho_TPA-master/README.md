# Trabalho de TPA

Trabalho de técnicas de programação avançada - Sistema prestadora de serviço de manutenção usando a API Swing.

O objetivo do trabalho é aprender o padrão de arquitetura de software MVC (model-view-controller) e o uso da API Swing - inicialmente, é isso.

Desenvolvido para disciplina de Técnicas de Programação Avançada.

Universidade Federal Fluminense - UFF de Rio das Ostras.

Alunos: Daniel Rodrigues, Nayara Cunha e Sthefany Peixoto.
